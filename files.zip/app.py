import os
from datetime import date, timedelta

import pandas as pd
import plotly.express as px
import plotly.graph_objects as go
import streamlit as st
from groq import Groq

# ----------------------------------------------------------------------------
# Page setup
# ----------------------------------------------------------------------------
st.set_page_config(page_title="AI Expense Analyzer", page_icon="💸", layout="wide")

CATEGORIES = [
    "Food & Dining", "Groceries", "Transport", "Rent & Utilities", "Shopping",
    "Entertainment", "Health", "Education", "Travel", "Subscriptions", "Other",
]
COLUMNS = ["id", "date", "amount", "category", "description"]
MODELS = ["llama-3.3-70b-versatile", "llama-3.1-8b-instant", "mixtral-8x7b-32768"]

# ----------------------------------------------------------------------------
# Session state
# ----------------------------------------------------------------------------
if "expenses" not in st.session_state:
    st.session_state.expenses = pd.DataFrame(columns=COLUMNS)
if "next_id" not in st.session_state:
    st.session_state.next_id = 1
if "chat" not in st.session_state:
    st.session_state.chat = []
if "report" not in st.session_state:
    st.session_state.report = ""


# ----------------------------------------------------------------------------
# Sidebar: settings
# ----------------------------------------------------------------------------
def default_key() -> str:
    try:
        if "GROQ_API_KEY" in st.secrets:
            return st.secrets["GROQ_API_KEY"]
    except Exception:
        pass
    return os.getenv("GROQ_API_KEY", "")


with st.sidebar:
    st.title("⚙️ Settings")
    api_key = st.text_input("Groq API Key", value=default_key(), type="password",
                            help="Get one at console.groq.com. You can also set GROQ_API_KEY.")
    model = st.selectbox("Model", MODELS)
    currency = st.text_input("Currency symbol", value="Rs.")
    st.divider()

    st.subheader("📂 Data")
    uploaded = st.file_uploader("Import CSV", type="csv",
                                help="Columns: date, amount, category, description")
    if uploaded is not None and st.button("Load CSV"):
        try:
            new = pd.read_csv(uploaded)
            new["date"] = pd.to_datetime(new["date"]).dt.date
            new["amount"] = pd.to_numeric(new["amount"])
            for col in ("category", "description"):
                if col not in new:
                    new[col] = "Other" if col == "category" else ""
            new = new[["date", "amount", "category", "description"]].copy()
            new.insert(0, "id", range(st.session_state.next_id, st.session_state.next_id + len(new)))
            st.session_state.next_id += len(new)
            st.session_state.expenses = pd.concat([st.session_state.expenses, new], ignore_index=True)
            st.success(f"Imported {len(new)} rows.")
        except Exception as e:
            st.error(f"Could not read CSV: {e}")

    if st.button("Load sample data"):
        import random
        random.seed(7)
        samples = [
            ("Lunch at burger place", "Food & Dining", 600, 1500),
            ("Uber ride to office", "Transport", 300, 900),
            ("Weekly vegetables and milk", "Groceries", 1500, 4000),
            ("Netflix subscription", "Subscriptions", 1100, 1100),
            ("New shoes from mall", "Shopping", 3000, 9000),
            ("Cinema tickets with friends", "Entertainment", 1200, 3000),
            ("Pharmacy medicines", "Health", 400, 2000),
            ("Dinner with family", "Food & Dining", 2500, 6000),
        ]
        rows = []
        for i in range(45):
            d = date.today() - timedelta(days=i)
            for _ in range(random.choice([0, 1, 1, 2])):
                desc, cat, lo, hi = random.choice(samples)
                rows.append((d, random.randint(lo, hi), cat, desc))
        new = pd.DataFrame(rows, columns=["date", "amount", "category", "description"])
        new.insert(0, "id", range(st.session_state.next_id, st.session_state.next_id + len(new)))
        st.session_state.next_id += len(new)
        st.session_state.expenses = pd.concat([st.session_state.expenses, new], ignore_index=True)
        st.rerun()

    if len(st.session_state.expenses):
        st.download_button("Export CSV",
                           st.session_state.expenses.drop(columns="id").to_csv(index=False),
                           file_name="expenses.csv", mime="text/csv")
        if st.button("🗑️ Clear all data"):
            st.session_state.expenses = pd.DataFrame(columns=COLUMNS)
            st.session_state.chat = []
            st.session_state.report = ""
            st.rerun()


# ----------------------------------------------------------------------------
# LLM helpers
# ----------------------------------------------------------------------------
def llm(messages, temperature=0.4, max_tokens=1500) -> str:
    if not api_key:
        return "⚠️ Please enter your Groq API key in the sidebar."
    try:
        client = Groq(api_key=api_key)
        resp = client.chat.completions.create(
            model=model, messages=messages, temperature=temperature, max_tokens=max_tokens
        )
        return resp.choices[0].message.content
    except Exception as e:
        return f"⚠️ Groq API error: {e}"


def ai_categorize(description: str) -> str:
    out = llm(
        [
            {"role": "system", "content": "You classify expenses. Reply with exactly one category "
             f"from this list and nothing else: {', '.join(CATEGORIES)}."},
            {"role": "user", "content": description},
        ],
        temperature=0, max_tokens=15,
    ).strip()
    for c in CATEGORIES:
        if c.lower() in out.lower():
            return c
    return "Other"


def build_summary(df: pd.DataFrame) -> str:
    d = df.copy()
    d["date"] = pd.to_datetime(d["date"])
    total = d["amount"].sum()
    daily = d.groupby("date")["amount"].sum()
    by_cat = d.groupby("category")["amount"].sum().sort_values(ascending=False)
    by_month = d.groupby(d["date"].dt.to_period("M"))["amount"].sum()
    by_wd = d.groupby(d["date"].dt.day_name())["amount"].mean().round(0)
    top_days = daily.sort_values(ascending=False).head(5)
    recent = d.sort_values("date", ascending=False).head(100)

    lines = [
        f"Currency: {currency}",
        f"Period: {d['date'].min().date()} to {d['date'].max().date()}",
        f"Total spent: {total:,.0f}; transactions: {len(d)}; avg per active day: {daily.mean():,.0f}",
        "Spending by category:\n" + "\n".join(f"- {k}: {v:,.0f} ({v / total:.0%})" for k, v in by_cat.items()),
        "Monthly totals:\n" + "\n".join(f"- {k}: {v:,.0f}" for k, v in by_month.items()),
        "Average spend by weekday:\n" + "\n".join(f"- {k}: {v:,.0f}" for k, v in by_wd.items()),
        "Top 5 highest-spend days:\n" + "\n".join(f"- {k.date()}: {v:,.0f}" for k, v in top_days.items()),
        "Recent transactions (date | amount | category | description):\n"
        + "\n".join(f"{r.date.date()} | {r.amount:,.0f} | {r.category} | {r.description}"
                    for r in recent.itertuples()),
    ]
    return "\n\n".join(lines)


SYSTEM_PROMPT = (
    "You are an expert personal finance coach. You receive a user's expense data, including "
    "free-text descriptions. Use the descriptions to detect behavioural patterns (impulse buys, "
    "habits, recurring costs, social spending, etc.). Be specific, cite numbers from the data, "
    "and be practical and non-judgmental."
)

REPORT_PROMPT = """Analyze the expense data below and respond in markdown with these sections:

## 🔍 Spending Patterns
## ⚠️ Problem Areas & High-Spend Triggers
## ✅ Good Habits
## 💡 Strategies to Reduce Expenses (5-7 concrete, prioritized, with estimated savings)
## 🎯 Suggested Monthly Budget (by category)

DATA:
{data}
"""


# ----------------------------------------------------------------------------
# Main UI
# ----------------------------------------------------------------------------
st.title("💸 AI Expense Analyzer")
st.caption("Log expenses, see charts and trends, and get AI-powered strategies (Groq).")

with st.expander("➕ Add an expense", expanded=len(st.session_state.expenses) == 0):
    with st.form("add_expense", clear_on_submit=True):
        c1, c2, c3 = st.columns([1, 1, 1])
        e_date = c1.date_input("Date", value=date.today())
        e_amount = c2.number_input("Amount", min_value=0.0, step=50.0, format="%.2f")
        e_cat = c3.selectbox("Category", ["🤖 Auto-detect (AI)"] + CATEGORIES)
        e_desc = st.text_input("Description", placeholder="e.g. Dinner with friends at Monal")
        if st.form_submit_button("Add expense", type="primary"):
            if e_amount <= 0:
                st.warning("Please enter an amount greater than 0.")
            else:
                cat = e_cat
                if e_cat.startswith("🤖"):
                    cat = ai_categorize(e_desc) if e_desc.strip() and api_key else "Other"
                row = pd.DataFrame([{
                    "id": st.session_state.next_id, "date": e_date, "amount": e_amount,
                    "category": cat, "description": e_desc.strip(),
                }])
                st.session_state.next_id += 1
                st.session_state.expenses = pd.concat([st.session_state.expenses, row], ignore_index=True)
                st.success(f"Added {currency} {e_amount:,.0f} under **{cat}**.")

df = st.session_state.expenses.copy()
if df.empty:
    st.info("No expenses yet. Add one above, import a CSV, or click **Load sample data** in the sidebar.")
    st.stop()

df["amount"] = df["amount"].astype(float)
df["date"] = pd.to_datetime(df["date"])

tab_dash, tab_trend, tab_ai, tab_data = st.tabs(
    ["📊 Dashboard", "📈 Trends", "🤖 AI Insights", "🗂️ Data"]
)

# ---------------------------- Dashboard -------------------------------------
with tab_dash:
    total = df["amount"].sum()
    daily = df.groupby("date")["amount"].sum()
    m1, m2, m3, m4 = st.columns(4)
    m1.metric("Total spent", f"{currency} {total:,.0f}")
    m2.metric("Transactions", len(df))
    m3.metric("Avg per active day", f"{currency} {daily.mean():,.0f}")
    top_cat = df.groupby("category")["amount"].sum().idxmax()
    m4.metric("Top category", top_cat)

    by_cat = df.groupby("category", as_index=False)["amount"].sum().sort_values("amount", ascending=False)
    left, right = st.columns(2)
    with left:
        fig = px.pie(by_cat, names="category", values="amount", hole=0.45,
                     title="Expense share by category")
        st.plotly_chart(fig, use_container_width=True)
    with right:
        fig = px.bar(by_cat, x="category", y="amount", color="category",
                     title="Total spend by category", text_auto=".0f")
        fig.update_layout(showlegend=False, yaxis_title=f"Amount ({currency})")
        st.plotly_chart(fig, use_container_width=True)

# ---------------------------- Trends ----------------------------------------
with tab_trend:
    full_range = pd.date_range(df["date"].min(), df["date"].max())
    daily = df.groupby("date")["amount"].sum().reindex(full_range, fill_value=0)
    tdf = daily.rename("amount").rename_axis("date").reset_index()
    mean, std = tdf["amount"].mean(), tdf["amount"].std(ddof=0)
    threshold = mean + std
    tdf["level"] = tdf["amount"].apply(
        lambda x: "🔴 High spending" if x > threshold else ("🟢 Normal / low" if x <= mean else "🟡 Moderate")
    )
    tdf["rolling7"] = tdf["amount"].rolling(7, min_periods=1).mean()

    st.subheader("Daily spending: when did we overspend?")
    fig = px.bar(
        tdf, x="date", y="amount", color="level",
        color_discrete_map={"🔴 High spending": "#e74c3c", "🟡 Moderate": "#f1c40f",
                            "🟢 Normal / low": "#2ecc71"},
    )
    fig.add_trace(go.Scatter(x=tdf["date"], y=tdf["rolling7"], mode="lines", name="7-day average",
                             line=dict(color="#2c3e50", width=3)))
    fig.add_hline(y=threshold, line_dash="dash", line_color="red",
                  annotation_text=f"High-spend threshold ({currency} {threshold:,.0f})")
    fig.update_layout(yaxis_title=f"Amount ({currency})", legend_title="")
    st.plotly_chart(fig, use_container_width=True)

    high_days = tdf[tdf["amount"] > threshold].sort_values("amount", ascending=False)
    ok_days = int((tdf["amount"] <= mean).sum())
    c1, c2 = st.columns(2)
    c1.metric("🔴 High-spend days", len(high_days))
    c2.metric("🟢 Normal / low days", ok_days)

    l, r = st.columns(2)
    with l:
        monthly = df.groupby(df["date"].dt.to_period("M").astype(str))["amount"].sum().reset_index()
        monthly.columns = ["month", "amount"]
        fig = px.line(monthly, x="month", y="amount", markers=True, title="Monthly trend")
        fig.update_layout(yaxis_title=f"Amount ({currency})")
        st.plotly_chart(fig, use_container_width=True)
    with r:
        order = ["Monday", "Tuesday", "Wednesday", "Thursday", "Friday", "Saturday", "Sunday"]
        wd = tdf.assign(weekday=tdf["date"].dt.day_name()).groupby("weekday")["amount"].mean()
        wd = wd.reindex(order).reset_index()
        fig = px.bar(wd, x="weekday", y="amount", title="Average spend by weekday", text_auto=".0f")
        fig.update_layout(yaxis_title=f"Avg amount ({currency})")
        st.plotly_chart(fig, use_container_width=True)

    if len(high_days):
        st.subheader("Your top overspending days")
        show = high_days.head(10)[["date", "amount"]].copy()
        show["what you bought"] = show["date"].apply(
            lambda d: "; ".join(df[df["date"] == d]["description"].replace("", "-"))
        )
        show["date"] = show["date"].dt.date
        st.dataframe(show, use_container_width=True, hide_index=True)

# ---------------------------- AI Insights -----------------------------------
with tab_ai:
    st.subheader("AI spending analysis & strategies")
    if st.button("🧠 Analyze my expenses", type="primary"):
        with st.spinner("Groq is analyzing your spending patterns..."):
            st.session_state.report = llm(
                [
                    {"role": "system", "content": SYSTEM_PROMPT},
                    {"role": "user", "content": REPORT_PROMPT.format(data=build_summary(df))},
                ],
                max_tokens=2000,
            )
    if st.session_state.report:
        st.markdown(st.session_state.report)

    st.divider()
    st.subheader("💬 Ask follow-up questions")
    for m in st.session_state.chat:
        with st.chat_message(m["role"]):
            st.markdown(m["content"])

    if q := st.chat_input("e.g. How can I cut my food costs by 20%?"):
        st.session_state.chat.append({"role": "user", "content": q})
        with st.chat_message("user"):
            st.markdown(q)
        msgs = [{"role": "system",
                 "content": SYSTEM_PROMPT + "\n\nUSER EXPENSE DATA:\n" + build_summary(df)}]
        msgs += st.session_state.chat[-10:]
        with st.chat_message("assistant"):
            with st.spinner("Thinking..."):
                ans = llm(msgs)
            st.markdown(ans)
        st.session_state.chat.append({"role": "assistant", "content": ans})

# ---------------------------- Data ------------------------------------------
with tab_data:
    st.subheader("All expenses")
    view = df.sort_values("date", ascending=False).copy()
    view["date"] = view["date"].dt.date
    st.dataframe(view, use_container_width=True, hide_index=True)

    to_delete = st.multiselect(
        "Select expense IDs to delete", view["id"].tolist(),
        format_func=lambda i: f"#{i} — {view[view['id'] == i]['description'].iloc[0] or 'no description'} "
                              f"({currency} {view[view['id'] == i]['amount'].iloc[0]:,.0f})",
    )
    if to_delete and st.button("Delete selected"):
        st.session_state.expenses = st.session_state.expenses[
            ~st.session_state.expenses["id"].isin(to_delete)
        ].reset_index(drop=True)
        st.rerun()
